package com.properties;

public class PropertiesActivity {

}
